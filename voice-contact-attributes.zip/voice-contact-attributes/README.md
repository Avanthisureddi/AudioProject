# Voice Contact Attributes

This project is a small Spring Boot service for estimating a caller’s gender and age bracket from short voice clips. It is meant for logistics and support workflows where audio is often noisy, compressed, and only a few seconds long. The service focuses on practical checks first: it reads the file, measures how usable the signal is, and only then makes a prediction.

The app runs on Java 21 and exposes a simple HTTP API. It can also stream analysis over WebSocket for progressive updates. The project keeps things lightweight and explainable instead of depending on a large black-box model. It uses audio features like pitch, RMS, clipping, and spectral balance to estimate attributes and quality.

Quick start:

```bash
cd /Users/avanthisureddi/IdeaProjects/voice-contact-attributes
export PATH=/Users/avanthisureddi/.local/apache-maven-3.9.9/bin:$PATH
mvn test
mvn spring-boot:run
```

Then call the API:

```bash
curl -s -F "audio=@samples/sample-male.wav" \
  -F "contact_id=11111111-1111-1111-1111-111111111111" \
  http://localhost:8080/analyze
```

It returns a structured result with prediction, confidence, and quality metadata. If the audio is too degraded, the service is designed to avoid overconfident output and return a safer result instead of pretending it knows more than it does.

This project is not meant to be a final production-grade voice intelligence stack. It is a useful base for a real system: better data collection, stronger calibration, a more robust quality gate, and eventually a more accurate ML model behind the same interface.

It also keeps privacy in mind. Audio is processed in memory for the request and metadata is stored without keeping raw audio around. That fits the kind of contact-center and field-service workflows this project was built for.
