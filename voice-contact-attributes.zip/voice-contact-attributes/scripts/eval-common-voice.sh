#!/usr/bin/env bash
set -euo pipefail
#
# Prepare a tiny labeled slice for EvalHarness from Mozilla Common Voice.
# 1. Download a Common Voice corpus (en) from https://commonvoice.mozilla.org
# 2. Point this script at the extracted folder that contains validated.tsv and clips/
#
# Usage:
#   ./scripts/eval-common-voice.sh /path/to/cv-corpus-xx-en ./eval-data
#   java -cp target/classes com.logistics.voice.attributes.eval.EvalHarness ./eval-data
#
SRC="${1:?common voice root}"
OUT="${2:-./eval-data}"
mkdir -p "$OUT"

python3 - <<'PY' "$SRC" "$OUT"
import csv, sys, pathlib, shutil
src, out = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2])
tsv = src / "validated.tsv"
clips = src / "clips"
if not tsv.exists():
    sys.exit(f"missing {tsv}")

def age_bracket(raw: str) -> str | None:
    raw = (raw or "").strip().lower()
    mapping = {
        "teens": "18-30",
        "twenties": "18-30",
        "thirties": "31-45",
        "fourties": "46-60",
        "forties": "46-60",
        "fifties": "46-60",
        "sixties": "60+",
        "seventies": "60+",
        "eighties": "60+",
        "nineties": "60+",
    }
    return mapping.get(raw)

written = 0
with tsv.open(newline="", encoding="utf-8") as f, (out / "labels.csv").open("w", newline="") as w:
    reader = csv.DictReader(f, delimiter="\t")
    writer = csv.writer(w)
    writer.writerow(["filename", "gender", "age_bracket"])
    for row in reader:
        gender = (row.get("gender") or "").strip().lower()
        if gender not in {"male", "female"}:
            continue
        bracket = age_bracket(row.get("age") or "")
        if not bracket:
            continue
        clip = clips / row["path"]
        if not clip.exists():
            continue
        dest = out / clip.name
        shutil.copy2(clip, dest)
        writer.writerow([clip.name, gender, bracket])
        written += 1
        if written >= 200:
            break
print(f"copied {written} clips to {out}")
PY
