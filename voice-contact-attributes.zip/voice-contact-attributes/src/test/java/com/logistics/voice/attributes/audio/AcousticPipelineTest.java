package com.logistics.voice.attributes.audio;

import static org.assertj.core.api.Assertions.assertThat;

import com.logistics.voice.attributes.domain.AudioQuality;
import org.junit.jupiter.api.Test;

class AcousticPipelineTest {

    private final AudioDecoder decoder = new AudioDecoder(16_000, "ffmpeg", System.getProperty("java.io.tmpdir"));
    private final AudioQualityAssessor qualityAssessor = new AudioQualityAssessor(400);
    private final PitchDetector pitchDetector = new PitchDetector();
    private final GenderEstimator genderEstimator = new GenderEstimator(155, 165);

    @Test
    void maleLikeToneIsPredictedMale() {
        byte[] wav = WavWriter.pcm16le(VoiceLikeTone.male(16_000, 1.5), 16_000);
        var pcm = decoder.decode(wav, "male.wav");
        var pitch = pitchDetector.estimate(pcm);
        var quality = qualityAssessor.assess(pcm);
        var gender = genderEstimator.estimate(pitch, quality.quality());

        assertThat(quality.quality()).isEqualTo(AudioQuality.GOOD);
        assertThat(pitch.medianHz()).isBetween(90.0, 160.0);
        assertThat(gender.prediction()).isEqualTo("male");
        assertThat(gender.confidence()).isGreaterThan(0.4);
    }

    @Test
    void femaleLikeToneIsPredictedFemale() {
        byte[] wav = WavWriter.pcm16le(VoiceLikeTone.female(16_000, 1.5), 16_000);
        var pcm = decoder.decode(wav, "female.wav");
        var pitch = pitchDetector.estimate(pcm);
        var quality = qualityAssessor.assess(pcm);
        var gender = genderEstimator.estimate(pitch, quality.quality());

        assertThat(pitch.medianHz()).isBetween(180.0, 260.0);
        assertThat(gender.prediction()).isEqualTo("female");
    }

    @Test
    void silenceIsInsufficientAndUnknownGender() {
        byte[] wav = WavWriter.pcm16le(VoiceLikeTone.silence(16_000, 1.0), 16_000);
        var pcm = decoder.decode(wav, "silence.wav");
        var quality = qualityAssessor.assess(pcm);
        var gender = genderEstimator.estimate(pitchDetector.estimate(pcm), quality.quality());

        assertThat(quality.quality()).isEqualTo(AudioQuality.INSUFFICIENT);
        assertThat(gender.prediction()).isEqualTo("unknown");
    }
}
