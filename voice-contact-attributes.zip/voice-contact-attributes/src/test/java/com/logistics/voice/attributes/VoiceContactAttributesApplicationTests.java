package com.logistics.voice.attributes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VoiceContactAttributesApplicationTests {

    @Test
    void contextLoads() {
    }
}
