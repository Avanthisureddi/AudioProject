package com.logistics.voice.attributes.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.multipart;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.logistics.voice.attributes.audio.VoiceLikeTone;
import com.logistics.voice.attributes.audio.WavWriter;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class AnalyzeControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void analyzeMultipartReturnsContractShape() throws Exception {
        byte[] wav = WavWriter.pcm16le(VoiceLikeTone.male(16_000, 1.2), 16_000);
        MockMultipartFile audio = new MockMultipartFile("audio", "sample-male.wav", "audio/wav", wav);
        UUID contactId = UUID.fromString("11111111-1111-1111-1111-111111111111");

        mockMvc.perform(multipart("/analyze").file(audio).param("contact_id", contactId.toString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.contact_id").value(contactId.toString()))
                .andExpect(jsonPath("$.gender.prediction").value("male"))
                .andExpect(jsonPath("$.gender.confidence").isNumber())
                .andExpect(jsonPath("$.age_bracket.prediction").exists())
                .andExpect(jsonPath("$.age_bracket.confidence").isNumber())
                .andExpect(jsonPath("$.processing_ms").isNumber())
                .andExpect(jsonPath("$.audio_quality").value("good"));
    }

    @Test
    void analyzeRejectsEmptyUpload() throws Exception {
        MockMultipartFile audio = new MockMultipartFile("audio", "empty.wav", "audio/wav", new byte[0]);
        mockMvc.perform(multipart("/analyze").file(audio))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("audio_processing_error"));
    }
}
