package com.logistics.voice.attributes.config;

import com.logistics.voice.attributes.websocket.AnalyzeWebSocketHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    private final AnalyzeWebSocketHandler analyzeWebSocketHandler;

    public WebSocketConfig(AnalyzeWebSocketHandler analyzeWebSocketHandler) {
        this.analyzeWebSocketHandler = analyzeWebSocketHandler;
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(analyzeWebSocketHandler, "/ws/analyze").setAllowedOrigins("*");
    }
}
