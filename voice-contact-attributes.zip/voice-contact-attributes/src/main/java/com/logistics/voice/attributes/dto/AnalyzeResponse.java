package com.logistics.voice.attributes.dto;

import com.logistics.voice.attributes.domain.AudioQuality;
import java.util.UUID;

public record AnalyzeResponse(
        UUID contactId,
        AttributePrediction gender,
        AttributePrediction ageBracket,
        AttributePrediction language,
        long processingMs,
        AudioQuality audioQuality
) {
}
