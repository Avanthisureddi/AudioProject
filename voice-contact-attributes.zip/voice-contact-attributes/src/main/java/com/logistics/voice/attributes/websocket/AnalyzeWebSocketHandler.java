package com.logistics.voice.attributes.websocket;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.logistics.voice.attributes.audio.WavWriter;
import com.logistics.voice.attributes.dto.AnalyzeResponse;
import com.logistics.voice.attributes.dto.StreamPredictionEvent;
import com.logistics.voice.attributes.service.AnalyzeService;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.BinaryMessage;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.AbstractWebSocketHandler;

/**
 * Progressive inference: client sends audio chunks as binary frames.
 * After ~800 ms of buffered audio, a prediction is emitted; a text frame
 * {"event":"flush"} forces a final result.
 */
@Component
public class AnalyzeWebSocketHandler extends AbstractWebSocketHandler {

    private static final Logger log = LoggerFactory.getLogger(AnalyzeWebSocketHandler.class);
    private static final int MIN_BYTES_FOR_PARTIAL = 16_000;

    private final AnalyzeService analyzeService;
    private final ObjectMapper objectMapper;
    private final Map<String, SessionBuffer> buffers = new ConcurrentHashMap<>();

    public AnalyzeWebSocketHandler(AnalyzeService analyzeService, ObjectMapper objectMapper) {
        this.analyzeService = analyzeService;
        this.objectMapper = objectMapper;
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        UUID contactId = parseContactId(session);
        buffers.put(session.getId(), new SessionBuffer(contactId));
        session.sendMessage(new TextMessage(objectMapper.writeValueAsString(StreamPredictionEvent.ready(contactId))));
    }

    @Override
    protected void handleBinaryMessage(WebSocketSession session, BinaryMessage message) throws Exception {
        SessionBuffer buffer = buffers.get(session.getId());
        if (buffer == null) {
            return;
        }
        ByteBuffer payload = message.getPayload();
        byte[] chunk = new byte[payload.remaining()];
        payload.get(chunk);
        buffer.append(chunk);
        if (buffer.size() >= MIN_BYTES_FOR_PARTIAL) {
            emit(session, buffer, "partial");
        }
    }

    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
        SessionBuffer buffer = buffers.get(session.getId());
        if (buffer == null) {
            return;
        }
        String text = message.getPayload();
        if (text.contains("flush") || text.contains("complete")) {
            emit(session, buffer, "final");
            buffer.reset();
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        buffers.remove(session.getId());
    }

    private void emit(WebSocketSession session, SessionBuffer buffer, String event) throws IOException {
        if (buffer.size() < 44) {
            session.sendMessage(new TextMessage(objectMapper.writeValueAsString(
                    StreamPredictionEvent.error(buffer.contactId, "Not enough audio buffered yet"))));
            return;
        }
        try {
            byte[] audio = WavWriter.maybeWrapRawPcm(buffer.snapshot(), 16_000);
            AnalyzeResponse response = analyzeService.analyze(audio, "stream.wav", buffer.contactId);
            StreamPredictionEvent payload = new StreamPredictionEvent(
                    event,
                    response.contactId(),
                    estimateBufferedMs(buffer.size()),
                    response.gender(),
                    response.ageBracket(),
                    response.language(),
                    response.audioQuality(),
                    response.processingMs());
            session.sendMessage(new TextMessage(objectMapper.writeValueAsString(payload)));
        } catch (Exception ex) {
            log.warn("stream inference failed: {}", ex.getMessage());
            session.sendMessage(new TextMessage(objectMapper.writeValueAsString(
                    StreamPredictionEvent.error(buffer.contactId, ex.getMessage()))));
        }
    }

    private static UUID parseContactId(WebSocketSession session) {
        String query = session.getUri() == null ? null : session.getUri().getQuery();
        if (query != null && query.contains("contact_id=")) {
            try {
                return UUID.fromString(query.substring(query.indexOf("contact_id=") + 11).split("&")[0]);
            } catch (IllegalArgumentException ignored) {
                // fall through
            }
        }
        return UUID.randomUUID();
    }

    private static int estimateBufferedMs(int bytes) {
        return bytes / 32;
    }

    private static final class SessionBuffer {
        private final UUID contactId;
        private final ByteArrayOutputStream out = new ByteArrayOutputStream();

        private SessionBuffer(UUID contactId) {
            this.contactId = contactId;
        }

        private synchronized void append(byte[] chunk) throws IOException {
            out.write(chunk);
        }

        private synchronized byte[] snapshot() {
            return out.toByteArray();
        }

        private synchronized int size() {
            return out.size();
        }

        private synchronized void reset() {
            out.reset();
        }
    }
}
