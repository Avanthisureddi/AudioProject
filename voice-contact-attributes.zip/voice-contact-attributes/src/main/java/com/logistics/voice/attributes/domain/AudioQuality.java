package com.logistics.voice.attributes.domain;

import com.fasterxml.jackson.annotation.JsonValue;

public enum AudioQuality {
    GOOD("good"),
    DEGRADED("degraded"),
    INSUFFICIENT("insufficient");

    private final String apiValue;

    AudioQuality(String apiValue) {
        this.apiValue = apiValue;
    }

    @JsonValue
    public String getApiValue() {
        return apiValue;
    }
}
