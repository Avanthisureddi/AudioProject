package com.logistics.voice.attributes.audio;

/**
 * Harmonic source-filter voice-like tones used for local tests and demos.
 * Not real speech; F0 is controlled so gender heuristics are deterministic.
 */
public final class VoiceLikeTone {

    private VoiceLikeTone() {
    }

    public static float[] synthesize(int sampleRate, double seconds, double f0Hz, double[] formants) {
        int n = (int) Math.round(sampleRate * seconds);
        float[] samples = new float[n];
        double[] phases = new double[formants.length];
        for (int i = 0; i < n; i++) {
            double t = i / (double) sampleRate;
            double glottal = 0;
            for (int h = 1; h <= 8; h++) {
                glottal += Math.sin(2 * Math.PI * f0Hz * h * t) / h;
            }
            double y = 0;
            for (int f = 0; f < formants.length; f++) {
                phases[f] += 2 * Math.PI * formants[f] / sampleRate;
                y += glottal * Math.sin(phases[f]) / (f + 1);
            }
            double envelope = 0.25 + 0.15 * Math.sin(2 * Math.PI * 3 * t);
            samples[i] = (float) (0.35 * envelope * y);
        }
        return samples;
    }

    public static float[] male(int sampleRate, double seconds) {
        return synthesize(sampleRate, seconds, 120, new double[] {700, 1220, 2600});
    }

    public static float[] female(int sampleRate, double seconds) {
        return synthesize(sampleRate, seconds, 220, new double[] {850, 1450, 2800});
    }

    public static float[] silence(int sampleRate, double seconds) {
        return new float[(int) Math.round(sampleRate * seconds)];
    }

    public static float[] noisy(float[] clean, double noiseGain) {
        float[] out = new float[clean.length];
        java.util.Random random = new java.util.Random(42);
        for (int i = 0; i < clean.length; i++) {
            out[i] = (float) (clean[i] + noiseGain * (random.nextGaussian()));
        }
        return out;
    }
}
