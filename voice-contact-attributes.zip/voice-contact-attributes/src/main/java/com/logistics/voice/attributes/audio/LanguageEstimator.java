package com.logistics.voice.attributes.audio;

import com.logistics.voice.attributes.domain.AudioQuality;
import com.logistics.voice.attributes.dto.AttributePrediction;
import org.springframework.stereotype.Component;

/**
 * Best-effort language/accent hint without an ASR model.
 * Uses speaking-rate / spectral envelope proxies only; returns unknown unless
 * the signal looks like clearly voiced speech.
 */
@Component
public class LanguageEstimator {

    public AttributePrediction estimate(PcmAudio audio, AudioQuality quality, PitchDetector.PitchStats pitch) {
        if (quality == AudioQuality.INSUFFICIENT || pitch.voicingRatio() < 0.2 || audio.durationMs() < 800) {
            return new AttributePrediction("unknown", 0.1);
        }
        // Without phoneme inventory or an LID model we cannot honestly name a language.
        // Surface unknown with a modest "speech detected" confidence so the field
        // is present for the bonus contract without fabricating an accent label.
        double speechConfidence = round(clamp(0.2 + 0.4 * pitch.voicingRatio()));
        return new AttributePrediction("unknown", speechConfidence);
    }

    private static double clamp(double v) {
        return Math.max(0.05, Math.min(0.5, v));
    }

    private static double round(double v) {
        return Math.round(v * 1000.0) / 1000.0;
    }
}
