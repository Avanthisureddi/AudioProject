package com.logistics.voice.attributes.dto;

public record AttributePrediction(String prediction, double confidence) {
}
