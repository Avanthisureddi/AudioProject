package com.logistics.voice.attributes.entity;

import com.logistics.voice.attributes.domain.AgeBracket;
import com.logistics.voice.attributes.domain.AudioQuality;
import com.logistics.voice.attributes.domain.Gender;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.Instant;
import java.util.UUID;

/**
 * Persists inference metadata only. Audio bytes are never stored.
 */
@Entity
@Table(name = "analysis_results")
public class AnalysisResult {

    @Id
    @Column(nullable = false, updatable = false)
    private UUID id;

    @Column(name = "contact_id", nullable = false)
    private UUID contactId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Gender genderPrediction;

    @Column(nullable = false)
    private double genderConfidence;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AgeBracket agePrediction;

    @Column(nullable = false)
    private double ageConfidence;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AudioQuality audioQuality;

    @Column(nullable = false)
    private long processingMs;

    @Column(nullable = false)
    private Instant createdAt;

    public UUID getId() {
        return id;
    }

    public void setId(UUID id) {
        this.id = id;
    }

    public UUID getContactId() {
        return contactId;
    }

    public void setContactId(UUID contactId) {
        this.contactId = contactId;
    }

    public Gender getGenderPrediction() {
        return genderPrediction;
    }

    public void setGenderPrediction(Gender genderPrediction) {
        this.genderPrediction = genderPrediction;
    }

    public double getGenderConfidence() {
        return genderConfidence;
    }

    public void setGenderConfidence(double genderConfidence) {
        this.genderConfidence = genderConfidence;
    }

    public AgeBracket getAgePrediction() {
        return agePrediction;
    }

    public void setAgePrediction(AgeBracket agePrediction) {
        this.agePrediction = agePrediction;
    }

    public double getAgeConfidence() {
        return ageConfidence;
    }

    public void setAgeConfidence(double ageConfidence) {
        this.ageConfidence = ageConfidence;
    }

    public AudioQuality getAudioQuality() {
        return audioQuality;
    }

    public void setAudioQuality(AudioQuality audioQuality) {
        this.audioQuality = audioQuality;
    }

    public long getProcessingMs() {
        return processingMs;
    }

    public void setProcessingMs(long processingMs) {
        this.processingMs = processingMs;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Instant createdAt) {
        this.createdAt = createdAt;
    }
}
