package com.logistics.voice.attributes.audio;

import com.logistics.voice.attributes.domain.AudioQuality;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AudioQualityAssessor {

    private final int minDurationMs;

    public AudioQualityAssessor(@Value("${app.audio.min-duration-ms}") int minDurationMs) {
        this.minDurationMs = minDurationMs;
    }

    public QualityReport assess(PcmAudio audio) {
        float[] samples = audio.samples();
        int durationMs = audio.durationMs();
        if (samples.length == 0 || durationMs < minDurationMs) {
            return new QualityReport(AudioQuality.INSUFFICIENT, 0, 0, 0, 0, durationMs);
        }

        double sumSq = 0;
        int clipped = 0;
        double peak = 0;
        for (float sample : samples) {
            double a = Math.abs(sample);
            peak = Math.max(peak, a);
            sumSq += sample * sample;
            if (a > 0.98) {
                clipped++;
            }
        }
        double rms = Math.sqrt(sumSq / samples.length);
        double clippingRatio = clipped / (double) samples.length;

        int frame = Math.max(1, audio.sampleRate() / 50);
        double[] frameRms = frameEnergies(samples, frame);
        java.util.Arrays.sort(frameRms);
        double p10 = percentile(frameRms, 0.10);
        double p50 = percentile(frameRms, 0.50);
        double dynamicRange = p50 / (p10 + 1e-9);
        boolean pauseLikeNoiseFloor = dynamicRange >= 3.0;
        double snrDb = 20 * Math.log10((p50 + 1e-9) / (p10 + 1e-9));
        if (!pauseLikeNoiseFloor && rms >= 0.02) {
            snrDb = 20;
        }

        AudioQuality quality;
        if (rms < 0.008 || peak < 0.02 || (pauseLikeNoiseFloor && snrDb < 3)) {
            quality = AudioQuality.INSUFFICIENT;
        } else if (clippingRatio > 0.02
                || audio.sampleRate() < 8000
                || (pauseLikeNoiseFloor && snrDb < 12)
                || (rms > 0.02 && dynamicRange < 1.15 && p10 > 0.05)) {
            quality = AudioQuality.DEGRADED;
        } else {
            quality = AudioQuality.GOOD;
        }
        return new QualityReport(quality, rms, snrDb, clippingRatio, peak, durationMs);
    }

    private static double[] frameEnergies(float[] samples, int frame) {
        int frames = Math.max(1, samples.length / frame);
        double[] energies = new double[frames];
        for (int f = 0; f < frames; f++) {
            double e = 0;
            int start = f * frame;
            int end = Math.min(start + frame, samples.length);
            for (int i = start; i < end; i++) {
                e += samples[i] * samples[i];
            }
            energies[f] = Math.sqrt(e / Math.max(1, end - start));
        }
        return energies;
    }

    private static double percentile(double[] sorted, double p) {
        int idx = Math.min(sorted.length - 1, Math.max(0, (int) Math.round(p * (sorted.length - 1))));
        return sorted[idx];
    }

    public record QualityReport(
            AudioQuality quality,
            double rms,
            double snrDb,
            double clippingRatio,
            double peak,
            int durationMs) {
    }
}
