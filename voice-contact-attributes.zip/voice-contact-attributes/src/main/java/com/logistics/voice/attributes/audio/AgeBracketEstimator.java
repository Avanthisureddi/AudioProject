package com.logistics.voice.attributes.audio;

import com.logistics.voice.attributes.domain.AgeBracket;
import com.logistics.voice.attributes.domain.AudioQuality;
import com.logistics.voice.attributes.dto.AttributePrediction;
import org.springframework.stereotype.Component;

/**
 * Best-effort acoustic age proxy. Age from a few seconds of noisy telephony
 * audio is weakly identifiable; we keep confidence conservative and fall back
 * to unknown when quality is poor.
 */
@Component
public class AgeBracketEstimator {

    public AttributePrediction estimate(
            PitchDetector.PitchStats pitch,
            SpectralFeatures.Features spectral,
            AudioQuality quality) {
        if (quality == AudioQuality.INSUFFICIENT) {
            return new AttributePrediction(AgeBracket.UNKNOWN.getApiValue(), 0.12);
        }

        double score = 0;
        // Younger adult speech tends to be brighter; older speech often has more
        // cycle-to-cycle instability (jitter) and a lower spectral centroid.
        score += Math.tanh((spectral.spectralCentroidHz() - 1800) / 800.0);
        score += 0.6 * Math.tanh((spectral.brightness() - 0.35) / 0.3);
        score -= 1.2 * Math.tanh(spectral.jitter() * 8);
        if (pitch.medianHz() > 200) {
            score += 0.15;
        } else if (pitch.medianHz() > 0 && pitch.medianHz() < 110) {
            score -= 0.2;
        }

        AgeBracket bracket;
        if (score > 0.55) {
            bracket = AgeBracket.AGE_18_30;
        } else if (score > 0.05) {
            bracket = AgeBracket.AGE_31_45;
        } else if (score > -0.45) {
            bracket = AgeBracket.AGE_46_60;
        } else {
            bracket = AgeBracket.AGE_60_PLUS;
        }

        double confidence = 0.28 + 0.18 * pitch.voicingRatio();
        if (quality == AudioQuality.DEGRADED) {
            confidence *= 0.65;
            if (confidence < 0.35) {
                bracket = AgeBracket.UNKNOWN;
            }
        }
        return new AttributePrediction(bracket.getApiValue(), round(clamp(confidence)));
    }

    private static double clamp(double v) {
        return Math.max(0.08, Math.min(0.72, v));
    }

    private static double round(double v) {
        return Math.round(v * 1000.0) / 1000.0;
    }
}
