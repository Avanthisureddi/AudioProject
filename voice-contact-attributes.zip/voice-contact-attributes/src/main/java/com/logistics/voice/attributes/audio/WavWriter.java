package com.logistics.voice.attributes.audio;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

public final class WavWriter {

    private WavWriter() {
    }

    public static byte[] pcm16le(float[] samples, int sampleRate) {
        byte[] data = new byte[samples.length * 2];
        ByteBuffer pcm = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        for (float sample : samples) {
            float clipped = Math.max(-1f, Math.min(1f, sample));
            pcm.putShort((short) Math.round(clipped * 32767f));
        }
        return wrap(data, sampleRate);
    }

    public static byte[] wrap(byte[] pcm16le, int sampleRate) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(44 + pcm16le.length);
        try {
            out.write("RIFF".getBytes(StandardCharsets.US_ASCII));
            writeInt(out, 36 + pcm16le.length);
            out.write("WAVE".getBytes(StandardCharsets.US_ASCII));
            out.write("fmt ".getBytes(StandardCharsets.US_ASCII));
            writeInt(out, 16);
            writeShort(out, 1);
            writeShort(out, 1);
            writeInt(out, sampleRate);
            writeInt(out, sampleRate * 2);
            writeShort(out, 2);
            writeShort(out, 16);
            out.write("data".getBytes(StandardCharsets.US_ASCII));
            writeInt(out, pcm16le.length);
            out.write(pcm16le);
        } catch (Exception e) {
            throw new IllegalStateException("Failed to write WAV header", e);
        }
        return out.toByteArray();
    }

    public static byte[] maybeWrapRawPcm(byte[] audio, int sampleRate) {
        if (audio.length >= 12
                && audio[0] == 'R'
                && audio[1] == 'I'
                && audio[2] == 'F'
                && audio[3] == 'F') {
            return audio;
        }
        return wrap(audio, sampleRate);
    }

    private static void writeInt(ByteArrayOutputStream out, int value) {
        out.write(value);
        out.write(value >> 8);
        out.write(value >> 16);
        out.write(value >> 24);
    }

    private static void writeShort(ByteArrayOutputStream out, int value) {
        out.write(value);
        out.write(value >> 8);
    }
}
