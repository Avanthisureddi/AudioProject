package com.logistics.voice.attributes.audio;

/**
 * In-memory PCM after decode. Never written to durable storage.
 */
public record PcmAudio(float[] samples, int sampleRate) {

    public int durationMs() {
        if (sampleRate <= 0 || samples.length == 0) {
            return 0;
        }
        return (int) Math.round(samples.length * 1000.0 / sampleRate);
    }
}
