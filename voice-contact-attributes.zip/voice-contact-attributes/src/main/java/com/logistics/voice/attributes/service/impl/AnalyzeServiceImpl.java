package com.logistics.voice.attributes.service.impl;

import com.logistics.voice.attributes.audio.AgeBracketEstimator;
import com.logistics.voice.attributes.audio.AudioDecoder;
import com.logistics.voice.attributes.audio.AudioQualityAssessor;
import com.logistics.voice.attributes.audio.AudioQualityAssessor.QualityReport;
import com.logistics.voice.attributes.audio.GenderEstimator;
import com.logistics.voice.attributes.audio.LanguageEstimator;
import com.logistics.voice.attributes.audio.PcmAudio;
import com.logistics.voice.attributes.audio.PitchDetector;
import com.logistics.voice.attributes.audio.SpectralFeatures;
import com.logistics.voice.attributes.domain.AgeBracket;
import com.logistics.voice.attributes.domain.AudioQuality;
import com.logistics.voice.attributes.domain.Gender;
import com.logistics.voice.attributes.dto.AnalyzeResponse;
import com.logistics.voice.attributes.dto.AttributePrediction;
import com.logistics.voice.attributes.entity.AnalysisResult;
import com.logistics.voice.attributes.repository.AnalysisResultRepository;
import com.logistics.voice.attributes.service.AnalyzeService;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import java.time.Instant;
import java.util.Locale;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AnalyzeServiceImpl implements AnalyzeService {

    private static final Logger log = LoggerFactory.getLogger(AnalyzeServiceImpl.class);

    private final AudioDecoder audioDecoder;
    private final AudioQualityAssessor qualityAssessor;
    private final PitchDetector pitchDetector;
    private final SpectralFeatures spectralFeatures;
    private final GenderEstimator genderEstimator;
    private final AgeBracketEstimator ageBracketEstimator;
    private final LanguageEstimator languageEstimator;
    private final AnalysisResultRepository analysisResultRepository;
    private final Timer inferenceTimer;

    public AnalyzeServiceImpl(
            AudioDecoder audioDecoder,
            AudioQualityAssessor qualityAssessor,
            PitchDetector pitchDetector,
            SpectralFeatures spectralFeatures,
            GenderEstimator genderEstimator,
            AgeBracketEstimator ageBracketEstimator,
            LanguageEstimator languageEstimator,
            AnalysisResultRepository analysisResultRepository,
            MeterRegistry meterRegistry) {
        this.audioDecoder = audioDecoder;
        this.qualityAssessor = qualityAssessor;
        this.pitchDetector = pitchDetector;
        this.spectralFeatures = spectralFeatures;
        this.genderEstimator = genderEstimator;
        this.ageBracketEstimator = ageBracketEstimator;
        this.languageEstimator = languageEstimator;
        this.analysisResultRepository = analysisResultRepository;
        this.inferenceTimer = Timer.builder("voice.analyze.duration")
                .description("End-to-end attribute inference")
                .register(meterRegistry);
    }

    @Override
    @Transactional
    public AnalyzeResponse analyze(byte[] audioBytes, String filenameHint, UUID contactId) {
        return inferenceTimer.record(() -> doAnalyze(audioBytes, filenameHint, contactId));
    }

    private AnalyzeResponse doAnalyze(byte[] audioBytes, String filenameHint, UUID contactId) {
        long started = System.nanoTime();
        UUID resolvedContactId = contactId == null ? UUID.randomUUID() : contactId;
        MDC.put("contactId", resolvedContactId.toString());

        PcmAudio pcm = audioDecoder.decode(audioBytes, filenameHint);
        QualityReport quality = qualityAssessor.assess(pcm);
        PitchDetector.PitchStats pitch = pitchDetector.estimate(pcm);
        SpectralFeatures.Features spectral = spectralFeatures.extract(pcm);

        AttributePrediction gender = genderEstimator.estimate(pitch, quality.quality());
        AttributePrediction age = ageBracketEstimator.estimate(pitch, spectral, quality.quality());
        AttributePrediction language = languageEstimator.estimate(pcm, quality.quality(), pitch);

        if (quality.quality() == AudioQuality.INSUFFICIENT) {
            gender = new AttributePrediction(Gender.UNKNOWN.getApiValue(), Math.min(gender.confidence(), 0.2));
            age = new AttributePrediction(AgeBracket.UNKNOWN.getApiValue(), Math.min(age.confidence(), 0.2));
            language = new AttributePrediction("unknown", Math.min(language.confidence(), 0.15));
        }

        long processingMs = (System.nanoTime() - started) / 1_000_000L;
        AnalysisResult saved = persist(resolvedContactId, gender, age, quality.quality(), processingMs);

        log.info(
                "analyzed contact={} quality={} snr_db={} rms={} gender={} age={} duration_ms={} processing_ms={}",
                resolvedContactId,
                quality.quality(),
                String.format(Locale.US, "%.1f", quality.snrDb()),
                String.format(Locale.US, "%.4f", quality.rms()),
                gender.prediction(),
                age.prediction(),
                quality.durationMs(),
                processingMs);

        return new AnalyzeResponse(
                saved.getContactId(), gender, age, language, processingMs, quality.quality());
    }

    private AnalysisResult persist(
            UUID contactId,
            AttributePrediction gender,
            AttributePrediction age,
            AudioQuality quality,
            long processingMs) {
        AnalysisResult entity = new AnalysisResult();
        entity.setId(UUID.randomUUID());
        entity.setContactId(contactId);
        entity.setGenderPrediction(Gender.valueOf(gender.prediction().toUpperCase(Locale.ROOT)));
        entity.setGenderConfidence(gender.confidence());
        entity.setAgePrediction(parseAge(age.prediction()));
        entity.setAgeConfidence(age.confidence());
        entity.setAudioQuality(quality);
        entity.setProcessingMs(processingMs);
        entity.setCreatedAt(Instant.now());
        return analysisResultRepository.save(entity);
    }

    private static AgeBracket parseAge(String apiValue) {
        for (AgeBracket bracket : AgeBracket.values()) {
            if (bracket.getApiValue().equals(apiValue)) {
                return bracket;
            }
        }
        return AgeBracket.UNKNOWN;
    }
}
