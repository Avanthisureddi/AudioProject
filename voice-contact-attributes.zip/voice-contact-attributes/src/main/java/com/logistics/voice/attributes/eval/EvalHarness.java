package com.logistics.voice.attributes.eval;

import com.logistics.voice.attributes.audio.AgeBracketEstimator;
import com.logistics.voice.attributes.audio.AudioDecoder;
import com.logistics.voice.attributes.audio.AudioQualityAssessor;
import com.logistics.voice.attributes.audio.GenderEstimator;
import com.logistics.voice.attributes.audio.PcmAudio;
import com.logistics.voice.attributes.audio.PitchDetector;
import com.logistics.voice.attributes.audio.SpectralFeatures;
import com.logistics.voice.attributes.dto.AttributePrediction;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Offline eval against a labeled folder (e.g. a Common Voice slice).
 *
 * Expected layout:
 *   labels.csv  with header: filename,gender,age_bracket
 *   *.wav files referenced by that CSV
 *
 * Gender labels: male|female
 * Age labels: 18-30|31-45|46-60|60+
 *
 * Common Voice mapping is documented in scripts/eval-common-voice.sh
 */
public final class EvalHarness {

    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.err.println("Usage: EvalHarness <dataset-dir-with-labels.csv>");
            System.exit(1);
        }
        Path root = Path.of(args[0]);
        Path csv = root.resolve("labels.csv");
        if (!Files.exists(csv)) {
            System.err.println("Missing " + csv);
            System.exit(1);
        }

        AudioDecoder decoder = new AudioDecoder(16_000, "ffmpeg", System.getProperty("java.io.tmpdir"));
        AudioQualityAssessor quality = new AudioQualityAssessor(400);
        PitchDetector pitch = new PitchDetector();
        SpectralFeatures spectral = new SpectralFeatures();
        GenderEstimator genderEstimator = new GenderEstimator(155, 165);
        AgeBracketEstimator ageEstimator = new AgeBracketEstimator();

        List<Row> rows = readLabels(csv);
        int genderCorrect = 0;
        int ageCorrect = 0;
        int usable = 0;
        List<Double> genderConfidences = new ArrayList<>();
        List<Boolean> genderHits = new ArrayList<>();

        for (Row row : rows) {
            Path wav = root.resolve(row.filename);
            if (!Files.exists(wav)) {
                System.err.println("skip missing " + wav);
                continue;
            }
            PcmAudio pcm = decoder.decode(Files.readAllBytes(wav), row.filename);
            var q = quality.assess(pcm);
            if (q.quality().getApiValue().equals("insufficient")) {
                continue;
            }
            usable++;
            var p = pitch.estimate(pcm);
            AttributePrediction g = genderEstimator.estimate(p, q.quality());
            AttributePrediction a = ageEstimator.estimate(p, spectral.extract(pcm), q.quality());
            boolean gHit = g.prediction().equalsIgnoreCase(row.gender);
            boolean aHit = a.prediction().equals(row.ageBracket);
            if (gHit) {
                genderCorrect++;
            }
            if (aHit) {
                ageCorrect++;
            }
            genderConfidences.add(g.confidence());
            genderHits.add(gHit);
            System.out.printf(
                    Locale.US,
                    "%s truth=%s/%s pred=%s(%.2f)/%s(%.2f) quality=%s%n",
                    row.filename,
                    row.gender,
                    row.ageBracket,
                    g.prediction(),
                    g.confidence(),
                    a.prediction(),
                    a.confidence(),
                    q.quality().getApiValue());
        }

        System.out.println("---");
        System.out.printf(Locale.US, "usable_clips=%d%n", usable);
        if (usable > 0) {
            System.out.printf(Locale.US, "gender_accuracy=%.3f%n", genderCorrect / (double) usable);
            System.out.printf(Locale.US, "age_accuracy=%.3f%n", ageCorrect / (double) usable);
            System.out.printf(Locale.US, "gender_ece=%.3f%n", expectedCalibrationError(genderConfidences, genderHits));
        }
    }

    private static double expectedCalibrationError(List<Double> confidences, List<Boolean> hits) {
        int bins = 10;
        double[] binConf = new double[bins];
        double[] binAcc = new double[bins];
        int[] binCount = new int[bins];
        for (int i = 0; i < confidences.size(); i++) {
            int bin = Math.min(bins - 1, (int) (confidences.get(i) * bins));
            binConf[bin] += confidences.get(i);
            binAcc[bin] += hits.get(i) ? 1 : 0;
            binCount[bin]++;
        }
        double ece = 0;
        int n = confidences.size();
        for (int b = 0; b < bins; b++) {
            if (binCount[b] == 0) {
                continue;
            }
            double acc = binAcc[b] / binCount[b];
            double conf = binConf[b] / binCount[b];
            ece += (binCount[b] / (double) n) * Math.abs(acc - conf);
        }
        return ece;
    }

    private static List<Row> readLabels(Path csv) throws Exception {
        List<String> lines = Files.readAllLines(csv);
        List<Row> rows = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i).trim();
            if (line.isEmpty() || (i == 0 && line.toLowerCase(Locale.ROOT).startsWith("filename"))) {
                continue;
            }
            String[] parts = line.split(",");
            if (parts.length < 3) {
                continue;
            }
            rows.add(new Row(parts[0].trim(), parts[1].trim().toLowerCase(Locale.ROOT), parts[2].trim()));
        }
        return rows;
    }

    private record Row(String filename, String gender, String ageBracket) {
    }
}
