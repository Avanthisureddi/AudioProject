package com.logistics.voice.attributes.audio;

import org.springframework.stereotype.Component;

@Component
public class SpectralFeatures {

    public Features extract(PcmAudio audio) {
        float[] samples = audio.samples();
        int n = nextPow2(Math.min(samples.length, audio.sampleRate()));
        if (n < 64) {
            return new Features(0, 0, 0, 0, 0);
        }
        double[] re = new double[n];
        double[] im = new double[n];
        int offset = Math.max(0, (samples.length - n) / 2);
        for (int i = 0; i < n; i++) {
            double window = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (n - 1));
            re[i] = samples[offset + i] * window;
        }
        fft(re, im);

        double spectralCentroid = 0;
        double magSum = 0;
        double highEnergy = 0;
        double lowEnergy = 0;
        double nyquist = audio.sampleRate() / 2.0;
        for (int k = 1; k < n / 2; k++) {
            double mag = Math.hypot(re[k], im[k]);
            double freq = k * (audio.sampleRate() / (double) n);
            magSum += mag;
            spectralCentroid += mag * freq;
            if (freq < 1000) {
                lowEnergy += mag;
            } else if (freq > 2500 && freq < nyquist) {
                highEnergy += mag;
            }
        }
        spectralCentroid = magSum == 0 ? 0 : spectralCentroid / magSum;
        double brightness = highEnergy / (lowEnergy + 1e-12);

        double zcr = zeroCrossingRate(samples);
        double jitter = amplitudeJitter(samples, audio.sampleRate());
        return new Features(spectralCentroid, brightness, zcr, jitter, magSum);
    }

    private static double zeroCrossingRate(float[] samples) {
        int crossings = 0;
        for (int i = 1; i < samples.length; i++) {
            if ((samples[i] >= 0) != (samples[i - 1] >= 0)) {
                crossings++;
            }
        }
        return crossings / (double) samples.length;
    }

    private static double amplitudeJitter(float[] samples, int sampleRate) {
        int hop = Math.max(1, sampleRate / 100);
        java.util.ArrayList<Double> peaks = new java.util.ArrayList<>();
        for (int i = hop; i < samples.length - hop; i += hop) {
            double max = 0;
            for (int j = i; j < i + hop && j < samples.length; j++) {
                max = Math.max(max, Math.abs(samples[j]));
            }
            peaks.add(max);
        }
        if (peaks.size() < 3) {
            return 0;
        }
        double diffs = 0;
        for (int i = 1; i < peaks.size(); i++) {
            diffs += Math.abs(peaks.get(i) - peaks.get(i - 1));
        }
        return diffs / (peaks.size() - 1);
    }

    private static int nextPow2(int n) {
        int p = 1;
        while (p < n && p < 4096) {
            p <<= 1;
        }
        return p;
    }

    static void fft(double[] re, double[] im) {
        int n = re.length;
        int j = 0;
        for (int i = 1; i < n; i++) {
            int bit = n >> 1;
            while (j >= bit) {
                j -= bit;
                bit >>= 1;
            }
            j += bit;
            if (i < j) {
                double tr = re[i];
                re[i] = re[j];
                re[j] = tr;
                double ti = im[i];
                im[i] = im[j];
                im[j] = ti;
            }
        }
        for (int len = 2; len <= n; len <<= 1) {
            double ang = -2 * Math.PI / len;
            double wlenRe = Math.cos(ang);
            double wlenIm = Math.sin(ang);
            for (int i = 0; i < n; i += len) {
                double wRe = 1;
                double wIm = 0;
                for (int k = 0; k < len / 2; k++) {
                    int u = i + k;
                    int v = u + len / 2;
                    double tRe = re[v] * wRe - im[v] * wIm;
                    double tIm = re[v] * wIm + im[v] * wRe;
                    re[v] = re[u] - tRe;
                    im[v] = im[u] - tIm;
                    re[u] += tRe;
                    im[u] += tIm;
                    double nWRe = wRe * wlenRe - wIm * wlenIm;
                    wIm = wRe * wlenIm + wIm * wlenRe;
                    wRe = nWRe;
                }
            }
        }
    }

    public record Features(
            double spectralCentroidHz,
            double brightness,
            double zeroCrossingRate,
            double jitter,
            double magnitudeSum) {
    }
}
