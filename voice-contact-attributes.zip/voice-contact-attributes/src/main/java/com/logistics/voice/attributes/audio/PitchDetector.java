package com.logistics.voice.attributes.audio;

import org.springframework.stereotype.Component;

/**
 * Autocorrelation pitch tracker over voiced frames.
 * Typical adult F0: ~85–180 Hz male, ~165–255 Hz female.
 */
@Component
public class PitchDetector {

    public PitchStats estimate(PcmAudio audio) {
        int sampleRate = audio.sampleRate();
        float[] samples = audio.samples();
        int minLag = Math.max(2, sampleRate / 350);
        int maxLag = Math.max(minLag + 1, sampleRate / 70);
        int window = Math.min(samples.length, (int) (0.04 * sampleRate));
        int hop = Math.max(1, window / 2);

        double voicedEnergy = 0;
        double totalEnergy = 0;
        java.util.ArrayList<Double> f0s = new java.util.ArrayList<>();

        for (int start = 0; start + window < samples.length; start += hop) {
            double energy = 0;
            for (int i = 0; i < window; i++) {
                energy += samples[start + i] * samples[start + i];
            }
            totalEnergy += energy;
            if (energy < 1e-5) {
                continue;
            }

            double bestCorr = 0;
            int bestLag = minLag;
            for (int lag = minLag; lag <= maxLag && start + window + lag < samples.length; lag++) {
                double corr = 0;
                double n0 = 0;
                double n1 = 0;
                for (int i = 0; i < window; i++) {
                    float a = samples[start + i];
                    float b = samples[start + i + lag];
                    corr += a * b;
                    n0 += a * a;
                    n1 += b * b;
                }
                double denom = Math.sqrt(n0 * n1) + 1e-12;
                double r = corr / denom;
                if (r > bestCorr) {
                    bestCorr = r;
                    bestLag = lag;
                }
            }
            if (bestCorr > 0.45) {
                f0s.add(sampleRate / (double) bestLag);
                voicedEnergy += energy;
            }
        }

        if (f0s.isEmpty()) {
            return new PitchStats(0, 0, 0, 0);
        }
        f0s.sort(Double::compareTo);
        double median = f0s.get(f0s.size() / 2);
        double mean = f0s.stream().mapToDouble(Double::doubleValue).average().orElse(0);
        double voicing = voicedEnergy / (totalEnergy + 1e-12);
        return new PitchStats(median, mean, voicing, f0s.size());
    }

    public record PitchStats(double medianHz, double meanHz, double voicingRatio, int voicedFrames) {
    }
}
