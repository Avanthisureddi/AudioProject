package com.logistics.voice.attributes.tools;

import com.logistics.voice.attributes.audio.VoiceLikeTone;
import com.logistics.voice.attributes.audio.WavWriter;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Writes deterministic WAV fixtures for smoke tests (not real caller speech).
 */
public final class GenerateSampleAudio {

    public static void main(String[] args) throws Exception {
        Path dir = Path.of(args.length > 0 ? args[0] : "samples");
        Files.createDirectories(dir);
        Files.write(dir.resolve("sample-male.wav"), WavWriter.pcm16le(VoiceLikeTone.male(16_000, 2.0), 16_000));
        Files.write(dir.resolve("sample-female.wav"), WavWriter.pcm16le(VoiceLikeTone.female(16_000, 2.0), 16_000));
        Files.write(
                dir.resolve("sample-noisy-warehouse.wav"),
                WavWriter.pcm16le(VoiceLikeTone.noisy(VoiceLikeTone.male(16_000, 2.0), 0.12), 16_000));
        Files.write(dir.resolve("sample-silence.wav"), WavWriter.pcm16le(VoiceLikeTone.silence(16_000, 1.0), 16_000));
        System.out.println("Wrote WAV fixtures to " + dir.toAbsolutePath());
    }
}
