package com.logistics.voice.attributes.repository;

import com.logistics.voice.attributes.entity.AnalysisResult;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnalysisResultRepository extends JpaRepository<AnalysisResult, UUID> {

    List<AnalysisResult> findByContactIdOrderByCreatedAtDesc(UUID contactId);
}
