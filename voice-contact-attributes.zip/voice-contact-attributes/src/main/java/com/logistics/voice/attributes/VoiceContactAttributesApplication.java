package com.logistics.voice.attributes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VoiceContactAttributesApplication {

    public static void main(String[] args) {
        SpringApplication.run(VoiceContactAttributesApplication.class, args);
    }
}
