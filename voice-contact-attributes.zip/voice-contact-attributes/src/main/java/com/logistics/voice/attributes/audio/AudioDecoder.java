package com.logistics.voice.attributes.audio;

import com.logistics.voice.attributes.exception.AudioProcessingException;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Decodes inbound call audio to 16 kHz mono float PCM.
 * Native path covers WAV PCM / µ-law / A-law (common in telephony).
 * ffmpeg covers compressed codecs (MP3, Opus, AMR) when available.
 */
@Component
public class AudioDecoder {

    private final int targetSampleRate;
    private final String ffmpegPath;
    private final Path tempDir;

    public AudioDecoder(
            @Value("${app.audio.target-sample-rate}") int targetSampleRate,
            @Value("${app.audio.ffmpeg-path}") String ffmpegPath,
            @Value("${app.audio.temp-dir}") String tempDir) {
        this.targetSampleRate = targetSampleRate;
        this.ffmpegPath = ffmpegPath;
        this.tempDir = Path.of(tempDir);
    }

    public PcmAudio decode(byte[] audioBytes, String filenameHint) {
        if (audioBytes == null || audioBytes.length < 12) {
            throw new AudioProcessingException("Audio payload is empty or too small");
        }
        if (isRiffWave(audioBytes)) {
            PcmAudio pcm = decodeWave(audioBytes);
            return resample(pcm, targetSampleRate);
        }
        return decodeWithFfmpeg(audioBytes, filenameHint);
    }

    private static boolean isRiffWave(byte[] bytes) {
        return bytes.length >= 12
                && bytes[0] == 'R'
                && bytes[1] == 'I'
                && bytes[2] == 'F'
                && bytes[3] == 'F'
                && bytes[8] == 'W'
                && bytes[9] == 'A'
                && bytes[10] == 'V'
                && bytes[11] == 'E';
    }

    PcmAudio decodeWave(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        buffer.position(12);
        int audioFormat = -1;
        int channels = 1;
        int sampleRate = targetSampleRate;
        int bitsPerSample = 16;
        byte[] data = null;

        while (buffer.remaining() >= 8) {
            byte[] chunkIdBytes = new byte[4];
            buffer.get(chunkIdBytes);
            String chunkId = new String(chunkIdBytes, StandardCharsets.US_ASCII);
            int chunkSize = buffer.getInt();
            if (chunkSize < 0 || chunkSize > buffer.remaining()) {
                throw new AudioProcessingException("Malformed WAV chunk: " + chunkId);
            }
            int next = buffer.position() + chunkSize + (chunkSize % 2);
            if ("fmt ".equals(chunkId)) {
                audioFormat = buffer.getShort() & 0xFFFF;
                channels = buffer.getShort() & 0xFFFF;
                sampleRate = buffer.getInt();
                buffer.getInt();
                buffer.getShort();
                bitsPerSample = buffer.getShort() & 0xFFFF;
            } else if ("data".equals(chunkId)) {
                data = new byte[chunkSize];
                buffer.get(data);
            }
            buffer.position(Math.min(next, buffer.limit()));
        }

        if (data == null) {
            throw new AudioProcessingException("WAV file is missing a data chunk");
        }
        float[] samples = switch (audioFormat) {
            case 1 -> decodePcm(data, bitsPerSample, channels);
            case 6 -> decodeG711(data, channels, true);
            case 7 -> decodeG711(data, channels, false);
            default -> throw new AudioProcessingException(
                    "Unsupported WAV format " + audioFormat + "; use ffmpeg-backed codecs in Docker");
        };
        return new PcmAudio(samples, sampleRate);
    }

    private static float[] decodePcm(byte[] data, int bitsPerSample, int channels) {
        if (bitsPerSample != 16) {
            throw new AudioProcessingException("Only 16-bit PCM WAV is supported without ffmpeg");
        }
        int frames = data.length / (2 * channels);
        float[] samples = new float[frames];
        ByteBuffer buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        for (int i = 0; i < frames; i++) {
            float mix = 0;
            for (int c = 0; c < channels; c++) {
                mix += buffer.getShort() / 32768.0f;
            }
            samples[i] = mix / channels;
        }
        return samples;
    }

    private static float[] decodeG711(byte[] data, int channels, boolean alaw) {
        int frames = data.length / channels;
        float[] samples = new float[frames];
        for (int i = 0; i < frames; i++) {
            float mix = 0;
            for (int c = 0; c < channels; c++) {
                int encoded = data[i * channels + c] & 0xFF;
                mix += (alaw ? alawToLinear(encoded) : ulawToLinear(encoded)) / 32768.0f;
            }
            samples[i] = mix / channels;
        }
        return samples;
    }

    private static int ulawToLinear(int uVal) {
        uVal = ~uVal;
        int t = ((uVal & 0x0F) << 3) + 0x84;
        t <<= (uVal & 0x70) >> 4;
        return ((uVal & 0x80) != 0) ? (0x84 - t) : (t - 0x84);
    }

    private static int alawToLinear(int aVal) {
        aVal ^= 0x55;
        int t = (aVal & 0x0F) << 4;
        int seg = (aVal & 0x70) >> 4;
        if (seg >= 1) {
            t += 0x108;
        }
        if (seg > 1) {
            t <<= seg - 1;
        } else if (seg == 0) {
            t += 8;
        }
        return ((aVal & 0x80) != 0) ? t : -t;
    }

    PcmAudio resample(PcmAudio audio, int newRate) {
        if (audio.sampleRate() == newRate) {
            return audio;
        }
        if (audio.sampleRate() <= 0) {
            throw new AudioProcessingException("Invalid sample rate");
        }
        double ratio = (double) newRate / audio.sampleRate();
        int newLength = Math.max(1, (int) Math.round(audio.samples().length * ratio));
        float[] out = new float[newLength];
        for (int i = 0; i < newLength; i++) {
            double src = i / ratio;
            int i0 = (int) Math.floor(src);
            int i1 = Math.min(i0 + 1, audio.samples().length - 1);
            float frac = (float) (src - i0);
            out[i] = audio.samples()[i0] * (1 - frac) + audio.samples()[i1] * frac;
        }
        return new PcmAudio(out, newRate);
    }

    private PcmAudio decodeWithFfmpeg(byte[] audioBytes, String filenameHint) {
        String ext = extension(filenameHint);
        Path input = null;
        Path output = null;
        try {
            Files.createDirectories(tempDir);
            input = Files.createTempFile(tempDir, "in-", ext);
            output = Files.createTempFile(tempDir, "out-", ".wav");
            Files.write(input, audioBytes);

            ProcessBuilder pb = new ProcessBuilder(
                    ffmpegPath,
                    "-y",
                    "-i", input.toAbsolutePath().toString(),
                    "-ac", "1",
                    "-ar", Integer.toString(targetSampleRate),
                    "-f", "wav",
                    "-acodec", "pcm_s16le",
                    output.toAbsolutePath().toString());
            pb.redirectErrorStream(true);
            Process process = pb.start();
            String logs = readFully(process.getInputStream());
            boolean finished = process.waitFor(20, TimeUnit.SECONDS);
            if (!finished) {
                process.destroyForcibly();
                throw new AudioProcessingException("ffmpeg timed out while decoding audio");
            }
            if (process.exitValue() != 0) {
                throw new AudioProcessingException("Unable to decode audio codec. ffmpeg: " + trim(logs));
            }
            byte[] wav = Files.readAllBytes(output);
            return decodeWave(wav);
        } catch (IOException e) {
            throw new AudioProcessingException(
                    "Compressed audio requires ffmpeg. Install ffmpeg or send WAV PCM / G.711.", e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new AudioProcessingException("Audio decode interrupted", e);
        } finally {
            deleteQuietly(input);
            deleteQuietly(output);
        }
    }

    private static String extension(String filenameHint) {
        if (filenameHint == null) {
            return ".bin";
        }
        String lower = filenameHint.toLowerCase(Locale.ROOT);
        int dot = lower.lastIndexOf('.');
        if (dot < 0) {
            return ".bin";
        }
        return lower.substring(dot);
    }

    private static String readFully(InputStream in) throws IOException {
        try (InputStream stream = in; ByteArrayInputStream ignored = new ByteArrayInputStream(new byte[0])) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            stream.transferTo(out);
            return out.toString(StandardCharsets.UTF_8);
        }
    }

    private static String trim(String logs) {
        String[] lines = logs.split("\n");
        return Arrays.stream(lines).reduce((a, b) -> b).orElse(logs);
    }

    private static void deleteQuietly(Path path) {
        if (path == null) {
            return;
        }
        try {
            Files.deleteIfExists(path);
        } catch (IOException ignored) {
            path.toFile().deleteOnExit();
        }
    }
}
