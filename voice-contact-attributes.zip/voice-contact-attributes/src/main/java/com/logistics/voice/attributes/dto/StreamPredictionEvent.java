package com.logistics.voice.attributes.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.logistics.voice.attributes.domain.AudioQuality;
import java.util.UUID;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record StreamPredictionEvent(
        String event,
        UUID contactId,
        int bufferedMs,
        AttributePrediction gender,
        AttributePrediction ageBracket,
        AttributePrediction language,
        AudioQuality audioQuality,
        long processingMs
) {
    public static StreamPredictionEvent ready(UUID contactId) {
        return new StreamPredictionEvent("ready", contactId, 0, null, null, null, null, 0);
    }

    public static StreamPredictionEvent error(UUID contactId, String message) {
        return new StreamPredictionEvent("error", contactId, 0,
                new AttributePrediction(message, 0.0), null, null, AudioQuality.INSUFFICIENT, 0);
    }
}
