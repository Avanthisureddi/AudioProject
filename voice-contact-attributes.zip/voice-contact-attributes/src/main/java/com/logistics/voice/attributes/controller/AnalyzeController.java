package com.logistics.voice.attributes.controller;

import com.logistics.voice.attributes.dto.AnalyzeResponse;
import com.logistics.voice.attributes.entity.AnalysisResult;
import com.logistics.voice.attributes.exception.AudioProcessingException;
import com.logistics.voice.attributes.repository.AnalysisResultRepository;
import com.logistics.voice.attributes.service.AnalyzeService;
import java.io.IOException;
import java.util.List;
import java.util.UUID;
import org.slf4j.MDC;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class AnalyzeController {

    private final AnalyzeService analyzeService;
    private final AnalysisResultRepository analysisResultRepository;

    public AnalyzeController(AnalyzeService analyzeService, AnalysisResultRepository analysisResultRepository) {
        this.analyzeService = analyzeService;
        this.analysisResultRepository = analysisResultRepository;
    }

    @PostMapping(path = "/analyze", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public AnalyzeResponse analyzeMultipart(
            @RequestPart("audio") MultipartFile audio,
            @RequestParam(value = "contact_id", required = false) UUID contactId) throws IOException {
        putRequestId();
        if (audio.isEmpty()) {
            throw new AudioProcessingException("Multipart field 'audio' is empty");
        }
        return analyzeService.analyze(audio.getBytes(), audio.getOriginalFilename(), contactId);
    }

    @PostMapping(
            path = "/analyze",
            consumes = {
                MediaType.APPLICATION_OCTET_STREAM_VALUE,
                "audio/wav",
                "audio/wave",
                "audio/x-wav",
                "audio/mpeg",
                "audio/ogg",
                "audio/webm"
            })
    public AnalyzeResponse analyzeRaw(
            @org.springframework.web.bind.annotation.RequestBody byte[] audio,
            @RequestHeader(value = "X-Contact-Id", required = false) UUID contactId,
            @RequestHeader(value = "X-Filename", required = false) String filename) {
        putRequestId();
        return analyzeService.analyze(audio, filename, contactId);
    }

    @GetMapping("/analyses/{contactId}")
    public List<AnalysisResult> history(@PathVariable UUID contactId) {
        return analysisResultRepository.findByContactIdOrderByCreatedAtDesc(contactId);
    }

    private static void putRequestId() {
        MDC.put("requestId", UUID.randomUUID().toString());
    }
}
