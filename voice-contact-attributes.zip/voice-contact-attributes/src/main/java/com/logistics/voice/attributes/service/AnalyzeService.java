package com.logistics.voice.attributes.service;

import com.logistics.voice.attributes.dto.AnalyzeResponse;
import java.util.UUID;

public interface AnalyzeService {

    AnalyzeResponse analyze(byte[] audioBytes, String filenameHint, UUID contactId);
}
