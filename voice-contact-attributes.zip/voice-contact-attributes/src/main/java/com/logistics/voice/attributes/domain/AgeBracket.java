package com.logistics.voice.attributes.domain;

import com.fasterxml.jackson.annotation.JsonValue;

public enum AgeBracket {
    AGE_18_30("18-30"),
    AGE_31_45("31-45"),
    AGE_46_60("46-60"),
    AGE_60_PLUS("60+"),
    UNKNOWN("unknown");

    private final String apiValue;

    AgeBracket(String apiValue) {
        this.apiValue = apiValue;
    }

    @JsonValue
    public String getApiValue() {
        return apiValue;
    }
}
