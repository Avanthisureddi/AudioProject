package com.logistics.voice.attributes.audio;

import com.logistics.voice.attributes.domain.AudioQuality;
import com.logistics.voice.attributes.domain.Gender;
import com.logistics.voice.attributes.dto.AttributePrediction;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class GenderEstimator {

    private final double maleF0Max;
    private final double femaleF0Min;

    public GenderEstimator(
            @Value("${app.inference.gender-male-f0-max-hz}") double maleF0Max,
            @Value("${app.inference.gender-female-f0-min-hz}") double femaleF0Min) {
        this.maleF0Max = maleF0Max;
        this.femaleF0Min = femaleF0Min;
    }

    public AttributePrediction estimate(PitchDetector.PitchStats pitch, AudioQuality quality) {
        if (quality == AudioQuality.INSUFFICIENT || pitch.voicedFrames() < 4 || pitch.medianHz() <= 0) {
            return new AttributePrediction(Gender.UNKNOWN.getApiValue(), 0.15);
        }

        double f0 = pitch.medianHz();
        Gender gender;
        double distance;
        if (f0 < maleF0Max) {
            gender = Gender.MALE;
            distance = (maleF0Max - f0) / maleF0Max;
        } else if (f0 > femaleF0Min) {
            gender = Gender.FEMALE;
            distance = (f0 - femaleF0Min) / femaleF0Min;
        } else {
            gender = Gender.UNKNOWN;
            distance = 0.1;
        }

        double confidence = clamp(0.35 + 0.45 * pitch.voicingRatio() + 0.3 * clamp(distance, 0, 1));
        if (quality == AudioQuality.DEGRADED) {
            confidence *= 0.7;
        }
        if (gender == Gender.UNKNOWN) {
            confidence = Math.min(confidence, 0.45);
        }
        return new AttributePrediction(gender.getApiValue(), round(confidence));
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static double clamp(double v) {
        return clamp(v, 0.05, 0.95);
    }

    private static double round(double v) {
        return Math.round(v * 1000.0) / 1000.0;
    }
}
